<?php
/*
	Plugin Name: Heart and Style Shortcodes
	Description: Shortcodes for the Heart and Style WordPress theme.
	Author: MeridianThemes
	Author URI: http://meridianthemes.net
	Version: 1.0
	Text Domain: heart-and-style-shortcodes
	License: GPLv2
	License URI: https://www.gnu.org/licenses/gpl-2.0.html
*/

define( 'HEART_AND_STYLE_SHORTCODES', plugin_dir_url( __FILE__ ) );

/**
 * Returns post meta value
 *
 * @since 1.0
 */
function heart_and_style_shortcodes_get_post_meta( $post_id, $option_id ) {

	$option_id = '_heart_and_style_' . $option_id;

	return get_post_meta( $post_id, $option_id , true );

}

function heart_and_style_shortcodes_scripts() {

	wp_enqueue_style( 'heart-and-style-shortcodes-css', HEART_AND_STYLE_SHORTCODES . 'css/main.css' );
	wp_enqueue_script( 'heart-and-style-shortcodes-js', HEART_AND_STYLE_SHORTCODES . 'js/main.js', array( 'jquery' ), '1.0', true );

} add_action( 'wp_enqueue_scripts', 'heart_and_style_shortcodes_scripts' );

function heart_and_style_shortcodes_style_list( $atts, $content ) {	

	return '<div class="heart-and-style-styled-list">' . $content . '</div>';

} add_shortcode( 'styled_list', 'heart_and_style_shortcodes_style_list' );

function heart_and_style_shortcodes_gallery( $atts, $content ) {

	// Attributes
	extract( shortcode_atts( array(
		'id' => false,
		'post_id' => false,
	), $atts));

	// Default value of output empty
	$output = '';

	// Post ID ( return if none )
	if ( get_the_ID() ) {
		$postID = get_the_ID();
	} else {
		return $output;
	}	
	
	// Gallery Images ( return if none )
	if ( heart_and_style_shortcodes_get_post_meta( $postID, 'gallery_images' ) ) {
		$gallery_images = heart_and_style_shortcodes_get_post_meta( $postID, 'gallery_images' );
	} else {
		return $output;
	}

	// If images not an array return
	if ( ! is_array( $gallery_images ) ) {
		return $output;
	}

	// Gallery Height
	$gallery_height = 230;
	if ( heart_and_style_shortcodes_get_post_meta( $postID, 'gallery_height', true ) ) {
		$gallery_height = heart_and_style_shortcodes_get_post_meta( $postID, 'gallery_height', true );
	}

	// Gallery Widths
	$site_width = 1084;

	// Start output fetching
	ob_start();

	$count_last_col = 0;

	if ( count( $gallery_images ) > 1 ) :

	?>

		<div class="heart-and-style-gallery clearfix">

			<?php foreach ( $gallery_images as $key => $gallery_image ) : ?>

				<?php

					$class_last_col = '';

					// Get sizes and classes
					if ( $gallery_image['size'] == '1/2' ) {
						$gallery_width = $site_width / 2;
						$gallery_size = '6';
					} elseif ( $gallery_image['size'] == '1/3' ) {
						$gallery_width = $site_width / 3;
						$gallery_size = '4';
					} elseif ( $gallery_image['size'] == '2/3' ) {
						$gallery_width = $site_width / 3 * 2;
						$gallery_size = '8';
					} else {
						$gallery_width = $site_width;
						$gallery_size = '12';
					}

					// Last col count
					$count_last_col += $gallery_size;

					if ( $count_last_col >= 12 ) {
						$class_last_col = 'col-last';
						$count_last_col = 0;
					} 

					// Get image
					if ( function_exists( 'heart_and_style_aq_resize' ) ) {
						$resized_img_src = heart_and_style_aq_resize( $gallery_image['image'], $gallery_width, $gallery_height, true );
					} else {
						$resized_img_src = $gallery_image['image'];
					}

				?>

				<div class="heart-and-style-gallery-item col col-<?php echo esc_attr( $gallery_size ); ?> <?php echo esc_attr( $class_last_col ); ?>" data-col-size="<?php echo esc_attr( $gallery_size ); ?>">

					<img src="<?php echo esc_url( $resized_img_src ); ?>" class="heart-and-style-trigger-lightbox-gallery" alt="" />

				</div><!-- .heart-and-style-gallery-item -->

			<?php endforeach; ?>

		</div><!-- .heart-and-style-gallery -->

		<div class="hidden-lightbox-gallery">
			
			<?php foreach ( $gallery_images as $gallery_image ) : ?>

				<a href="<?php echo esc_url( $gallery_image['image'] ); ?>"></a>

			<?php endforeach; ?>

		</div>

	<?php

	endif;

	// Get the output and stop fetching
	$output = ob_get_contents();
	ob_end_clean();

	return $output;

} add_shortcode( 'heart_and_style_gallery', 'heart_and_style_shortcodes_gallery' );