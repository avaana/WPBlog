"use strict";

jQuery(document).ready(function($){

	/**
	 * Styled List
	 */

	$('.heart-and-style-styled-list').each(function() {

		var numCount = 0;

		$(this).find('li').each(function(){
			numCount++;
			$(this).prepend( '<span class="styled-list-num">' + numCount + '</span>' );
		});

	});

	/**
	 * Gallery Images Popup
	 */

	 $(document).on( 'click', '.heart-and-style-gallery-item', function(){

	 	var imageIndex = jQuery(this).index() + 1;
	 	jQuery(this).closest('.heart-and-style-gallery').next('.hidden-lightbox-gallery').find('a:nth-child(' + imageIndex + ')').click();

	 });

});

jQuery(window).load(function(){

	/**
	 * Gallery Height Equalize
	 */

	jQuery('.heart-and-style-gallery').each(function(){

		// Min height per row
		var gallery = jQuery(this),
		galleryItems = gallery.find('.heeart-and-style-gallery-item'),
		maxHeight = 0,
		colCount = 0,
		colSize = 0;

		// Go through each item
		galleryItems.each(function(){

			// Item
			var galleryItem = jQuery(this),
			colSize = parseInt( galleryItem.data('col-size') );

			// Append count
			if ( colCount === undefined ) {
				colCount = 0;
			}
			colCount = colCount + colSize

			// Set class to apply height later
			galleryItem.addClass('heart-and-style-gallery-item-apply-height');

			// Find out max height
			if ( maxHeight == 0 || galleryItem.height() < maxHeight ) {
				maxHeight = galleryItem.height();
			}

			// If row ended set heights and reset count
			if ( colCount == 12 ) {
				jQuery('.heart-and-style-gallery-item-apply-height').css({ 'max-height' : maxHeight }).removeClass('heart-and-style-gallery-item-apply-height');
				colCount = 0;
			}

		});

	});

});